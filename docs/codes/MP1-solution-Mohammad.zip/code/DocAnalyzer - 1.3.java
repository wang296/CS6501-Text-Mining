/**
 * 
 */
package analyzer;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Date;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;

import json.JSONArray;
import json.JSONException;
import json.JSONObject;
import opennlp.tools.tokenize.Tokenizer;
import opennlp.tools.tokenize.TokenizerME;
import opennlp.tools.tokenize.TokenizerModel;

import org.tartarus.snowball.SnowballStemmer;
import org.tartarus.snowball.ext.englishStemmer;








import structures.Post;
import structures.Token;
/**
 * @author hongning
 * Sample codes for demonstrating OpenNLP package usage 
 * NOTE: the code here is only for demonstration purpose, 
 * please revise it accordingly to maximize your implementation's efficiency!
 */
public class DocAnalyzer   {
	ArrayList<Tokenizer> tokenizer; // need many because of the threading
	//a list of stopwords
	HashSet<String> m_stopwords;

	//you can store the loaded reviews in this arraylist for further processing
	ArrayList<Post> m_reviews;
	ArrayList<Post> m_TestReviews;
	//you might need something like this to store the counting statistics for validating Zipf's and computing IDF
	HashMap<String, Token> m_Vocabs;	

	private Object lock1 = new Object();
	private Object lock2 = new Object();
	private int MaxTokenID;
	private int NumberOfReviewsInTraining;
	public DocAnalyzer(int NumberOfProcessors,int NumberOfReviewsInTraining) {
		this.NumberOfReviewsInTraining=NumberOfReviewsInTraining;
		m_reviews = new ArrayList<Post>();
		m_TestReviews=new ArrayList<Post>();
		m_stopwords= new HashSet<String>();
		m_Vocabs=new HashMap<String, Token>();
		MaxTokenID=0;

		try {
			//tokenizer = new TokenizerME(new TokenizerModel(new FileInputStream("/cslab/home/ma2sm/hw1/data/Model/en-token.bin")));
			tokenizer=new ArrayList<Tokenizer>();
			for(int i=0;i<NumberOfProcessors;++i)
				tokenizer.add( new TokenizerME(new TokenizerModel(new FileInputStream("./data/Model/en-token.bin"))));
			// Load Stopwards
			LoadStopwords("./data/english.stop");
		}
		catch (IOException e) {
			e.printStackTrace();
		}
	}

	//sample code for loading a list of stopwords from file
	//you can manually modify the stopword file to include your newly selected words
	public void LoadStopwords(String filename) {
		try {
			BufferedReader reader = new BufferedReader(new InputStreamReader(new FileInputStream(filename), "UTF-8"));
			String line;

			while ((line = reader.readLine()) != null) {
				//it is very important that you perform the same processing operation to the loaded stopwords
				//otherwise it won't be matched in the text content
				line = SnowballStemmingDemo(NormalizationDemo(line));
				if (!line.isEmpty())
					m_stopwords.add(line);
			}
			reader.close();
			System.out.format("Loading %d stopwords from %s\n", m_stopwords.size(), filename);
		} catch(IOException e){
			System.err.format("[Error]Failed to open file %s!!", filename);
		}
	}
	//sample code for demonstrating how to use Snowball stemmer
	public String SnowballStemmingDemo(String token) {
		SnowballStemmer stemmer = new englishStemmer();
		stemmer.setCurrent(token);
		if (stemmer.stem())
			return stemmer.getCurrent();
		else
			return token;
	}
	public void analyzeDocumentDemo(JSONObject json,int core,boolean isTraining) {		
		try {
			JSONArray jarray = json.getJSONArray("Reviews");
			for(int i=0; i<jarray.length(); i++) {
				Post review = new Post(jarray.getJSONObject(i));
				// preprocess each token
				String previousToken="";
				for(String token:tokenizer.get(core).tokenize(review.getContent())){
					String finalToken=SnowballStemmingDemo(NormalizationDemo(token));
					if(!finalToken.isEmpty()) // if the token is empty, then try next token
					{ 

						synchronized(lock1) {
							//unigram
							if(m_Vocabs.containsKey(finalToken)){ 
								String vocabID=finalToken;
								if(!review.m_VSM.containsKey(vocabID))
									review.m_VSM.put(vocabID, 0.0);
								review.m_VSM.put(vocabID,review.m_VSM.get(vocabID)+1);// increase count
							}
							// bigram
							if(m_Vocabs.containsKey(previousToken+"-"+finalToken)){
								String vocabID=previousToken+"-"+finalToken;
								if(!review.m_VSM.containsKey(vocabID))
									review.m_VSM.put(vocabID, 0.0);
								review.m_VSM.put(vocabID,review.m_VSM.get(vocabID)+1);// increase count
							}
						}
					}
					previousToken=finalToken;
				}
				if(review.m_VSM.size()==0)// empty vector .. do not add
					continue;
				// normalize TF (Sub-linear TF scaling) and them multiply by IDF to obtain TF-IDF
				Set<String> set = review.m_VSM.keySet();
				Iterator<String> itr = set.iterator();
				while (itr.hasNext())
				{
					String key = itr.next();
					review.m_VSM.put(key,(1+Math.log10(review.m_VSM.get(key)))*(1+Math.log10(NumberOfReviewsInTraining/m_Vocabs.get(key).getValue())));
				}

				synchronized(lock2) {
					if(isTraining)
						m_reviews.add(review);
					else
						m_TestReviews.add(review);
				}
			}
		} catch (JSONException e) {
			e.printStackTrace();
		}
	}
	 //sample code for loading a json file
	public JSONObject LoadJson(String filename) {
		try {
			BufferedReader reader = new BufferedReader(new InputStreamReader(new FileInputStream(filename), "UTF-8"));
			StringBuffer buffer = new StringBuffer(1024);
			String line;

			while((line=reader.readLine())!=null) {
				buffer.append(line);
			}
			reader.close();

			return new JSONObject(buffer.toString());
		} catch (IOException e) {
			System.err.format("[Error]Failed to open file %s!", filename);
			e.printStackTrace();
			return null;
		} catch (JSONException e) {
			System.err.format("[Error]Failed to parse json file %s!", filename);
			e.printStackTrace();
			return null;
		}
	}

	public ArrayList<String> GetFiles(String folder, String suffix) {
		File dir = new File(folder);
		ArrayList<String> Files=new ArrayList<String>();
		for (File f : dir.listFiles()) {
			if (f.isFile() && f.getName().endsWith(suffix)){
				Files.add(f.getAbsolutePath());
			}
			else if (f.isDirectory())
				Files.addAll(GetFiles(f.getAbsolutePath(), suffix)) ;
		}
		return Files;
	}

	public void LoadVocab(String filename)
	{
		try {
			BufferedReader reader = new BufferedReader(new InputStreamReader(new FileInputStream(filename), "UTF-8"));
			String line;

			while ((line = reader.readLine()) != null) {
				//it is very important that you perform the same processing operation to the loaded stopwords
				//otherwise it won't be matched in the text content
				if (line.isEmpty())continue;
				String[] values=line.split(",");
				m_Vocabs.put(values[1],new Token(Integer.parseInt(values[0]),values[1],Double.parseDouble(values[2])));
			}
			reader.close();

		} catch(IOException e){
			System.err.format("[Error]Failed to open file !!" );
		}
	}

	public void GetTopNSimilarReviews(Post Source, int N){
		HashMap<Double,Integer> DistanceFromSource=new HashMap<Double,Integer>();
		// Calculate Distance
		for(int i=0;i<m_reviews.size();++i){
			if (i==6401)
				i=i+1-1;
			DistanceFromSource.put(ConsineDistance(Source.m_VSM, m_reviews.get(i).m_VSM),i);}
		// Sort
		Map<Double,Integer> map = new TreeMap<Double,Integer>(DistanceFromSource).descendingMap(); 
		// Save
		try {
			FileWriter fstream = new FileWriter("./"+Source.getID()+"_Sim.txt", false);
			BufferedWriter out = new BufferedWriter(fstream);
			out.write(Source.getID()+","+Source.getAuthor()+","+Source.getDate()+","+Source.getContent()+"\n");
			Set set2 = map.entrySet();
			Iterator iterator2 = set2.iterator();
			for(int i=0;i<N&&i<m_reviews.size();++i){
				Map.Entry me2 = (Map.Entry)iterator2.next();
				Post review=m_reviews.get((Integer) me2.getValue());
				out.write(me2.getKey()+","+ review.getID()+","+review.getAuthor()+","+review.getDate()+","+review.getContent()+"\n");
			}
			out.close();
			System.out.println( Source.getID()+"_Sim Saved!");
		} catch (Exception e) {
			e.printStackTrace(); 
		}
	}
	//sample code for demonstrating how to perform text normalization
	public String NormalizationDemo(String token) {
		// convert to lower case
		token = token.toLowerCase();
		//token = token.replaceAll("\\d+star(s)?", "RATE");// rating by stars
		// Some scales and measures
		//token = token.replaceAll("\\d+(oz|lb|lbs|cent|inch|piec)", "SCALE");
		// convert some of the dates/times formats
		//token = token.replaceAll("\\d{2}(:\\d{2})?(\\s)?(a|p)m", "TIME"); // 12 hours format
		//token = token.replaceAll("\\d{2}:\\d{2}", "TIME"); // 24 hours format
		//token = token.replaceAll("\\d{1,2}(th|nd|st|rd)", "DATE");// 1st 2nd 3rd 4th date format
		// convert numbers
		token = token.replaceAll("\\d+.\\d+", "NUM");		
		token = token.replaceAll("\\d+(ish)?", "NUM");
		// tested on "a 123 b 3123 c 235.123 d 0 e 0.3 f 213.231.1321 g +123 h -123.123"
		// remove punctuations
		token = token.replaceAll("\\p{Punct}", ""); 
		//tested on this string:  "This., -/ is #! an <>|~!@#$%^&*()_-+=}{[]\"':;?/>.<, $ % ^ & * example ;: {} of a = -_ string with `~)() punctuation" 
		return token;
	}
	public double ConsineDistance(HashMap<String,Double> d_i,HashMap<String,Double> d_j){
		// since the VSM are stored as sparse vectors, then in the nominator I will go through only the shared N-grams since d_i[k]*d_j[k] equals to zero if anyone of them is zero
		double dot=0;
		double d_iNorm=0;
		double d_jNorm=0;
		Set<String> set = d_i.keySet();
		Iterator<String> itr = set.iterator();
		// Calculate  the nominator and d_i norm
		while (itr.hasNext())
		{
			String key = itr.next();
			if(d_j.containsKey(key))
				dot+=d_i.get(key)*d_j.get(key);
			d_iNorm+=d_i.get(key)*d_i.get(key);
		}
		// Calculate the d_j norm
		set = d_j.keySet();
		itr = set.iterator();
		while (itr.hasNext())
		{
			String key = itr.next();
			d_jNorm+=d_j.get(key)*d_j.get(key);
		}
		// return the cosine distance
		// if one of the VSM has zeros for all terms, we will have zero in the denominator. Return -1 for this case
		return (d_iNorm==0||d_jNorm==0)?-1:dot/(Math.sqrt(d_iNorm)*Math.sqrt(d_jNorm));
	}
	 
	public static void main(String[] args) {	
		int NumberOfProcessors=8;
		DocAnalyzer analyzer = new DocAnalyzer(NumberOfProcessors,1993372);
		analyzer.LoadVocab( "./Vocab.csv");
		DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
		ArrayList<String>Files=analyzer.GetFiles("./data/Yelp/test", ".json");
		int FilesSize=Files.size();
		HashMap<Integer,String> ProcessingStatus = new HashMap<Integer, String>(); // used for output purposes
		for (int i = 1; i <= 10; i++)
			ProcessingStatus.put((int)(FilesSize * (i / 10d)), i+"0% ("+(int)(FilesSize * (i / 10d))+" out of "+FilesSize+")." );


		ArrayList<Thread> threads = new ArrayList<Thread>();
		for(int i=0;i<NumberOfProcessors;++i){
			threads.add(  (new Thread() {
				int core;
				public void run() {
					try {
						for (int j = 0; j + core <FilesSize; j +=NumberOfProcessors)
						{
							if (ProcessingStatus.containsKey(j + core))
								System.out.println(dateFormat.format(new Date())+" - Loaded " +ProcessingStatus.get(j + core));
							analyzer.analyzeDocumentDemo(analyzer.LoadJson(Files.get(j+core)),core,true);
						}
					} catch (Exception e) {
						e.printStackTrace();
					} 

				}
				private Thread initialize(int core) {
					this.core = core;
					return this;
				}
			}).initialize(i));
			threads.get(i).start();
		}
		for(int i=0;i<NumberOfProcessors;++i){
			try {
				threads.get(i).join();
			} catch (InterruptedException e) {
				e.printStackTrace();
			} 
		} 
		System.out.println(dateFormat.format(new Date())+" - Loaded all testing documents!");

		System.out.println(dateFormat.format(new Date())+" - Load query.json:");
		analyzer.analyzeDocumentDemo(analyzer.LoadJson("./data/Yelp/query.json"),1,false);
		System.out.println(dateFormat.format(new Date())+" - Loaded query.json!");


		// compute cosine distance and get closest docs from testing
		for(Post source:analyzer.m_TestReviews){
			analyzer.GetTopNSimilarReviews(source, 3);
		}
	}



}
