df<-read.csv('C:\\Users\\Mohammad\\Desktop\\d\\College\\BooksAndSlides\\2014\\semester 2-9\\Text Mining 6501-3\\HW1\\MP1\\Results\\Zipfs\\df.csv',header=FALSE,sep=',')
Ttf<-read.csv('C:\\Users\\Mohammad\\Desktop\\d\\College\\BooksAndSlides\\2014\\semester 2-9\\Text Mining 6501-3\\HW1\\MP1\\Results\\Zipfs\\Ttf.csv',header=FALSE,sep=',')
z<-lm(log10(V3)~log10(V1),  data = df)
summary(z)
z2<-lm(log10(V3)~log10(V1),  data = Ttf)
summary(z2)

plot(V3~V1,  data = df, type = "l", log="xy", main = "Zipf's Law (all special tokens included)"  ,col='blue',xlab="Index", ylab="Word frequency",xlim = c(1,  1e+06 ), ylim = c(1, 1e+07 ))
points(V3~V1,  data = Ttf, type = "l", col='red')
abline(b=-0.5, a= 6.4206667, col="yellow")

abline(b=-1, a= 7.5 , col="green")

abline(b=-2, a= 10.5 , col="cyan")

legend('topright', c('TTF','DF','1/x^0.5','1/x','1/x^2'),  lty=1, col=c('red', 'blue', 'green',' yellow','green','cyan'), bty='n', cex=.75)

df_Num<-read.csv('C:\\Users\\Mohammad\\Desktop\\d\\College\\BooksAndSlides\\2014\\semester 2-9\\Text Mining 6501-3\\HW1\\MP1\\Results\\Zipfs\\Df_NUM.csv',header=FALSE,sep=',')
Ttf_Num<-read.csv('C:\\Users\\Mohammad\\Desktop\\d\\College\\BooksAndSlides\\2014\\semester 2-9\\Text Mining 6501-3\\HW1\\MP1\\Results\\Zipfs\\Ttf_NUM.csv',header=FALSE,sep=',')

plot(V3~V1,  data = df_Num, type = "l", log="xy", main = "Zipf's Law (only NUM)"  ,col='blue',xlab="Index", ylab="Word frequency",xlim = c(1,  1e+06 ), ylim = c(1, 1e+07 ))
points(V3~V1,  data = Ttf_Num, type = "l", col='red')
abline(b=-0.5, a= 6.5 , col="yellow")

abline(b=-1, a= 7.5 , col="green")

abline(b=-2, a= 10.5 , col="cyan")

legend('topright', c('TTF','DF','1/x^0.5','1/x','1/x^2'),  lty=1, col=c('red', 'blue', 'green',' yellow','green','cyan'), bty='n', cex=.75)


df_NoNum<-read.csv('C:\\Users\\Mohammad\\Desktop\\d\\College\\BooksAndSlides\\2014\\semester 2-9\\Text Mining 6501-3\\HW1\\MP1\\Results\\Zipfs\\Df_NoNUM.csv',header=FALSE,sep=',')
Ttf_NoNum<-read.csv('C:\\Users\\Mohammad\\Desktop\\d\\College\\BooksAndSlides\\2014\\semester 2-9\\Text Mining 6501-3\\HW1\\MP1\\Results\\Zipfs\\Ttf_NoNUM.csv',header=FALSE,sep=',')

plot(V3~V1,  data = df_NoNum, type = "l", log="xy", main = "Zipf's Law (without numerical tokens)"  ,col='blue',xlab="Index", ylab="Word frequency",xlim = c(1,  1e+06 ), ylim = c(1, 1e+07 ))
points(V3~V1,  data = Ttf_NoNum, type = "l", col='red')
abline(b=-0.5, a= 6.5 , col="yellow")

abline(b=-1, a= 7.5 , col="green")

abline(b=-2, a= 10.5 , col="cyan")

legend('topright', c('TTF','DF','1/x^0.5','1/x','1/x^2'),  lty=1, col=c('red', 'blue', 'green',' yellow','green','cyan'), bty='n', cex=.75)

z3<-lm(log10(V3)~log10(V1),  data = df_NoNum)
summary(z3)
z4<-lm(log10(V3)~log10(V1),  data = Ttf_NoNum)
summary(z4)
--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
  # smoothing methods analysis
  
LI25<-read.csv('C:\\Users\\Mohammad\\Desktop\\d\\College\\BooksAndSlides\\2014\\semester 2-9\\Text Mining 6501-3\\HW1\\MP1\\Results\\2_1_analysis\\IL_good_0_25.csv',header=FALSE,sep=',')
LI50<-read.csv('C:\\Users\\Mohammad\\Desktop\\d\\College\\BooksAndSlides\\2014\\semester 2-9\\Text Mining 6501-3\\HW1\\MP1\\Results\\2_1_analysis\\IL_good_0_50.csv',header=FALSE,sep=',')
LI75<-read.csv('C:\\Users\\Mohammad\\Desktop\\d\\College\\BooksAndSlides\\2014\\semester 2-9\\Text Mining 6501-3\\HW1\\MP1\\Results\\2_1_analysis\\IL_good_0_75.csv',header=FALSE,sep=',')
LI90<-read.csv('C:\\Users\\Mohammad\\Desktop\\d\\College\\BooksAndSlides\\2014\\semester 2-9\\Text Mining 6501-3\\HW1\\MP1\\Results\\2_1_analysis\\IL_good_0_90.csv',header=FALSE,sep=',')
LI99<-read.csv('C:\\Users\\Mohammad\\Desktop\\d\\College\\BooksAndSlides\\2014\\semester 2-9\\Text Mining 6501-3\\HW1\\MP1\\Results\\2_1_analysis\\IL_good_0_99.csv',header=FALSE,sep=',')
plot(V3~V1,  data = LI25, type = "l", log="xy", main = "Linear Interpolation Smoothing"  ,col='blue',xlab="Index", ylab="Smoothed Probability")
points(V3~V1,  data = LI50, type = "l", col='red')
points(V3~V1,  data = LI75, type = "l", col='yellow')
points(V3~V1,  data = LI90, type = "l", col='green')
points(V3~V1,  data = LI99, type = "l", col='cyan')
legend('topright', c(expression(lambda == 0.25),expression(lambda == 0.5),expression(lambda == 0.75),expression(lambda == 0.90),expression(lambda == 0.99)),  lty=1, col=c('blue', 'red', 'yellow','green', 'cyan'), bty='n', cex=.75)

plot(V3~V1,  data = LI25, type = "l", log="xy", main = "Linear Interpolation Smoothing"  ,col='blue',xlab="Index", ylab="Smoothed Probability")
points(V3~V1,  data = LI99, type = "l", col='red')
legend('topright', c(expression(lambda == 0.25),expression(lambda == 0.99)),  lty=1, col=c('blue', 'red'), bty='n', cex=.75)



AD25<-read.csv('C:\\Users\\Mohammad\\Desktop\\d\\College\\BooksAndSlides\\2014\\semester 2-9\\Text Mining 6501-3\\HW1\\MP1\\Results\\2_1_analysis\\AD_good_0_25.csv',header=FALSE,sep=',')
AD50<-read.csv('C:\\Users\\Mohammad\\Desktop\\d\\College\\BooksAndSlides\\2014\\semester 2-9\\Text Mining 6501-3\\HW1\\MP1\\Results\\2_1_analysis\\AD_good_0_50.csv',header=FALSE,sep=',')
AD75<-read.csv('C:\\Users\\Mohammad\\Desktop\\d\\College\\BooksAndSlides\\2014\\semester 2-9\\Text Mining 6501-3\\HW1\\MP1\\Results\\2_1_analysis\\AD_good_0_75.csv',header=FALSE,sep=',')
AD90<-read.csv('C:\\Users\\Mohammad\\Desktop\\d\\College\\BooksAndSlides\\2014\\semester 2-9\\Text Mining 6501-3\\HW1\\MP1\\Results\\2_1_analysis\\AD_good_0_90.csv',header=FALSE,sep=',')
AD99<-read.csv('C:\\Users\\Mohammad\\Desktop\\d\\College\\BooksAndSlides\\2014\\semester 2-9\\Text Mining 6501-3\\HW1\\MP1\\Results\\2_1_analysis\\AD_good_0_99.csv',header=FALSE,sep=',')
plot(V3~V1,  data = AD25, type = "l", log="xy", main = "Absolute discounting Smoothing"  ,col='blue',xlab="Index", ylab="Smoothed Probability")
points(V3~V1,  data = AD50, type = "l", col='red')
points(V3~V1,  data = AD75, type = "l", col='yellow')
points(V3~V1,  data = AD90, type = "l", col='green')
points(V3~V1,  data = AD99, type = "l", col='cyan')
legend('topright', c(expression(delta == 0.25),expression(delta == 0.5),expression(delta == 0.75),expression(delta == 0.90),expression(delta == 0.99)),  lty=1, col=c('blue', 'red', 'yellow','green', 'cyan'), bty='n', cex=.75)

plot(V3~V1,  data = AD25, type = "l", log="xy", main = "Absolute discounting Smoothing"  ,col='blue',xlab="Index", ylab="Smoothed Probability")
points(V3~V1,  data = AD99, type = "l", col='red')
legend('topright', c(expression(delta == 0.25),expression(delta == 0.99)),  lty=1, col=c('blue', 'red'), bty='n', cex=.75)


------
uni<-read.csv('C:\\Users\\Mohammad\\Desktop\\d\\College\\BooksAndSlides\\2014\\semester 2-9\\Text Mining 6501-3\\HW1\\MP1\\uniPP.txt',header=FALSE,sep=',')
uni<-as.numeric(unlist(uni))
sd(uni)
mean(uni)
summary(uni)
quantile(uni)

bi1<-read.csv('C:\\Users\\Mohammad\\Desktop\\d\\College\\BooksAndSlides\\2014\\semester 2-9\\Text Mining 6501-3\\HW1\\MP1\\biLIPP.txt',header=FALSE,sep=',')
bi1<-as.numeric(unlist(bi1))
sd(bi1)
mean(bi1)
summary(bi1)
median(bi1)
quantile(bi1)
max(bi1)

bi2<-read.csv('C:\\Users\\Mohammad\\Desktop\\d\\College\\BooksAndSlides\\2014\\semester 2-9\\Text Mining 6501-3\\HW1\\MP1\\biADPP.txt',header=FALSE,sep=',')
bi2<-as.numeric(unlist(bi2))
sd(bi2)
mean(bi2)
summary(bi2)
median(bi2)
quantile(bi2)
max(bi2)
