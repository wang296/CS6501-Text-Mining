/**
 * 
 */
package analyzer;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Date;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Random;
import java.util.Set;
import java.util.TreeMap;

import json.JSONArray;
import json.JSONException;
import json.JSONObject;
import opennlp.tools.tokenize.Tokenizer;
import opennlp.tools.tokenize.TokenizerME;
import opennlp.tools.tokenize.TokenizerModel;

import org.tartarus.snowball.SnowballStemmer;
import org.tartarus.snowball.ext.englishStemmer;










import structures.LanguageModel;
import structures.Post;
import structures.Token;
/**
 * @author hongning
 * Sample codes for demonstrating OpenNLP package usage 
 * NOTE: the code here is only for demonstration purpose, 
 * please revise it accordingly to maximize your implementation's efficiency!
 */
public class DocAnalyzer   {
	ArrayList<Tokenizer> tokenizer; // need many because of the threading
	//a list of stopwords
	Random R;

	//you can store the loaded reviews in this arraylist for further processing
	ArrayList<Post> m_reviews;
	public LanguageModel m_unigramLM;
	public LanguageModel m_bigramLM;
	public int TotalNumberOfWords=0;
	private Object lock1 = new Object();
	private Object lock2 = new Object();
	public DocAnalyzer(int NumberOfProcessors ) {

		m_reviews = new ArrayList<Post>();
		m_unigramLM=new LanguageModel(1);
		R=new Random();
		m_bigramLM=new LanguageModel(2);
		m_bigramLM.m_reference=m_unigramLM;

		try {
			tokenizer=new ArrayList<Tokenizer>();
			for(int i=0;i<NumberOfProcessors;++i)
				tokenizer.add( new TokenizerME(new TokenizerModel(new FileInputStream("./data/Model/en-token.bin"))));

		}
		catch (IOException e) {
			e.printStackTrace();
		}
	}


	//sample code for demonstrating how to use Snowball stemmer
	public String SnowballStemmingDemo(String token) {
		SnowballStemmer stemmer = new englishStemmer();
		stemmer.setCurrent(token);
		if (stemmer.stem())
			return stemmer.getCurrent();
		else
			return token;
	}
	String previousToken="";
	public void analyzeDocumentDemo(JSONObject json,int index,int core ) {		
		try {
			JSONArray jarray = json.getJSONArray("Reviews");
			for(int i=0; i<jarray.length(); i++) {
				Post review = new Post(jarray.getJSONObject(i));
				double uni=1;
				double biLI=1;
				double biAD=1;
				int WordsCount=0;
				// get actual length of each review
				ArrayList<String> processedTokens=new ArrayList<String>();
				for(String token:tokenizer.get(core).tokenize(review.getContent())){
					String finalToken=SnowballStemmingDemo(NormalizationDemo(token));
					// if the token is empty, then try next token
					if(!finalToken.isEmpty()){ 
						WordsCount++;
						processedTokens.add(finalToken);
					}
				}
				String previousToken="";
				for(String finalToken:processedTokens){
						//unigram
						uni*=Math.pow(1/m_unigramLM.calcLinearSmoothedProb(finalToken), 1/(double)WordsCount);
						// bigram
						if(!previousToken.isEmpty()){
							String vocabID=previousToken+"-"+finalToken;
							biLI*=Math.pow(1/m_bigramLM.calcLinearSmoothedProb(vocabID), 1/(double)WordsCount);
							biAD*=Math.pow(1/m_bigramLM.calcAbsoluteDiscountSmoothedProb(vocabID), 1/(double)WordsCount);
						}
						previousToken=finalToken;
				}
				synchronized(lock1) {
					UniPP.get(index).add(uni);
					BiLIPP.get(index).add(biLI);
					BiADPP.get(index).add(biAD);
				}
			}
		} catch (JSONException e) {
			e.printStackTrace();
		}
	}
	public ArrayList<String> GetFiles(String folder, String suffix) {
		File dir = new File(folder);
		ArrayList<String> Files=new ArrayList<String>();
		for (File f : dir.listFiles()) {
			if (f.isFile() && f.getName().endsWith(suffix)){
				Files.add(f.getAbsolutePath());
			}
			else if (f.isDirectory())
				Files.addAll(GetFiles(f.getAbsolutePath(), suffix)) ;
		}
		return Files;
	}
	//sample code for loading a json file
	public JSONObject LoadJson(String filename) {
		try {
			BufferedReader reader = new BufferedReader(new InputStreamReader(new FileInputStream(filename), "UTF-8"));
			StringBuffer buffer = new StringBuffer(1024);
			String line;

			while((line=reader.readLine())!=null) {
				buffer.append(line);
			}
			reader.close();

			return new JSONObject(buffer.toString());
		} catch (IOException e) {
			System.err.format("[Error]Failed to open file %s!", filename);
			e.printStackTrace();
			return null;
		} catch (JSONException e) {
			System.err.format("[Error]Failed to parse json file %s!", filename);
			e.printStackTrace();
			return null;
		}
	}
	ArrayList<ArrayList<Double>> UniPP=new ArrayList<ArrayList<Double>>();
	ArrayList<ArrayList<Double>> BiLIPP=new ArrayList<ArrayList<Double>>();
	ArrayList<ArrayList<Double>> BiADPP=new ArrayList<ArrayList<Double>>();
	public void SavePP()
	{
		try {
			// uni
			FileWriter fstream = new FileWriter("./uniPP.txt", false);
			BufferedWriter out = new BufferedWriter(fstream);
			for(ArrayList<Double> doc:UniPP)
				for( Double  pp:doc)
					out.write(pp+"\n");
			out.close();
			System.out.println("uni pp Saved!");
			// bi LI
			fstream = new FileWriter("./biLIPP.txt", false);
			out = new BufferedWriter(fstream);
			for(ArrayList<Double> doc:BiLIPP)
				for( Double  pp:doc)
					out.write(pp+"\n");
			out.close();
			System.out.println("Bi li pp Saved!");
			// bi AD
			fstream = new FileWriter("./biADPP.txt", false);
			out = new BufferedWriter(fstream);
			for(ArrayList<Double> doc:BiADPP)
				for( Double  pp:doc)
					out.write(pp+"\n");
			out.close();
			System.out.println("Bi ad  pp Saved!");

		} catch (Exception e) {
			e.printStackTrace(); 
		}
	}
	//sample code for demonstrating how to perform text normalization
	public String NormalizationDemo(String token) {
		// convert to lower case
		token = token.toLowerCase();
		//token = token.replaceAll("\\d+star(s)?", "RATE");// rating by stars
		// Some scales and measures
		//token = token.replaceAll("\\d+(oz|lb|lbs|cent|inch|piec)", "SCALE");
		// convert some of the dates/times formats
		//token = token.replaceAll("\\d{2}(:\\d{2})?(\\s)?(a|p)m", "TIME"); // 12 hours format
		//token = token.replaceAll("\\d{2}:\\d{2}", "TIME"); // 24 hours format
		//token = token.replaceAll("\\d{1,2}(th|nd|st|rd)", "DATE");// 1st 2nd 3rd 4th date format
		// convert numbers
		token = token.replaceAll("\\d+.\\d+", "NUM");		
		token = token.replaceAll("\\d+(ish)?", "NUM");
		// tested on "a 123 b 3123 c 235.123 d 0 e 0.3 f 213.231.1321 g +123 h -123.123"
		// remove punctuations
		token = token.replaceAll("\\p{Punct}", ""); 
		//tested on this string:  "This., -/ is #! an <>|~!@#$%^&*()_-+=}{[]\"':;?/>.<, $ % ^ & * example ;: {} of a = -_ string with `~)() punctuation" 
		return token;
	}
	public enum SmoothingMethod {
		LinearInterpolation, AbsoluteDiscount
	}
	public static void main(String[] args) {	
		int NumberOfProcessors=8;
		DocAnalyzer analyzer = new DocAnalyzer(NumberOfProcessors );

		DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");

		analyzer.m_unigramLM.Load("uni_vocab");
		System.out.println("uni vocab loaded!");
		analyzer.m_bigramLM.Load("bi_vocab");
		System.out.println("bi vocab loaded!");

		ArrayList<String>Files=analyzer.GetFiles("./data/Yelp_small/test", ".json");//Yelp_small/train
		int FilesSize=Files.size();
		HashMap<Integer,String> ProcessingStatus = new HashMap<Integer, String>(); // used for output purposes
		for (int i = 1; i <= 10; i++)
			ProcessingStatus.put((int)(FilesSize * (i / 10d)), i+"0% ("+(int)(FilesSize * (i / 10d))+" out of "+FilesSize+")." );
		for(int i=0;i<FilesSize;++i)
		{
			analyzer.UniPP.add(new ArrayList<Double>());
			analyzer.BiLIPP.add(new ArrayList<Double>());
			analyzer.BiADPP.add(new ArrayList<Double>());
		}
		ArrayList<Thread> threads = new ArrayList<Thread>();
		for(int i=0;i<NumberOfProcessors;++i){
			threads.add(  (new Thread() {
				int core;
				public void run() {
					try {
						for (int j = 0; j + core <FilesSize; j +=NumberOfProcessors)
						{
							if (ProcessingStatus.containsKey(j + core))
								System.out.println(dateFormat.format(new Date())+" - Loaded " +ProcessingStatus.get(j + core));
							analyzer.analyzeDocumentDemo(analyzer.LoadJson(Files.get(j+core)),j+core,core);
						}
					} catch (Exception e) {
						e.printStackTrace();
					} 

				}
				private Thread initialize(int core) {
					this.core = core;
					return this;
				}
			}).initialize(i));
			threads.get(i).start();
		}
		for(int i=0;i<NumberOfProcessors;++i){
			try {
				threads.get(i).join();
			} catch (InterruptedException e) {
				e.printStackTrace();
			} 
		}
		// Save
		analyzer.SavePP();

	}



}
