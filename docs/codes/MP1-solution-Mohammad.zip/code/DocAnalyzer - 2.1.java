/**
 * 
 */
package analyzer;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Date;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;

import json.JSONArray;
import json.JSONException;
import json.JSONObject;
import opennlp.tools.tokenize.Tokenizer;
import opennlp.tools.tokenize.TokenizerME;
import opennlp.tools.tokenize.TokenizerModel;

import org.tartarus.snowball.SnowballStemmer;
import org.tartarus.snowball.ext.englishStemmer;









import structures.LanguageModel;
import structures.Post;
import structures.Token;
/**
 * @author hongning
 * Sample codes for demonstrating OpenNLP package usage 
 * NOTE: the code here is only for demonstration purpose, 
 * please revise it accordingly to maximize your implementation's efficiency!
 */
public class DocAnalyzer   {
	ArrayList<Tokenizer> tokenizer; // need many because of the threading
	//a list of stopwords


	//you can store the loaded reviews in this arraylist for further processing
	ArrayList<Post> m_reviews;
	public LanguageModel m_unigramLM;
	public LanguageModel m_bigramLM;
	public int TotalNumberOfWords=0;
	private Object lock1 = new Object();
	private Object lock2 = new Object();
	public DocAnalyzer(int NumberOfProcessors ) {

		m_reviews = new ArrayList<Post>();
		m_unigramLM=new LanguageModel(1);

		m_bigramLM=new LanguageModel(2);
		m_bigramLM.m_reference=m_unigramLM;

		try {
			tokenizer=new ArrayList<Tokenizer>();
			for(int i=0;i<NumberOfProcessors;++i)
				tokenizer.add( new TokenizerME(new TokenizerModel(new FileInputStream("./data/Model/en-token.bin"))));
			// Load Stopwards

		}
		catch (IOException e) {
			e.printStackTrace();
		}
	}


	//sample code for demonstrating how to use Snowball stemmer
	public String SnowballStemmingDemo(String token) {
		SnowballStemmer stemmer = new englishStemmer();
		stemmer.setCurrent(token);
		if (stemmer.stem())
			return stemmer.getCurrent();
		else
			return token;
	}
	public void analyzeDocumentDemo(JSONObject json,int core ) {		
		try {
			JSONArray jarray = json.getJSONArray("Reviews");
			for(int i=0; i<jarray.length(); i++) {
				Post review = new Post(jarray.getJSONObject(i));
				// preprocess each token
				String previousToken="";
				for(String token:tokenizer.get(core).tokenize(review.getContent())){
					String finalToken=SnowballStemmingDemo(NormalizationDemo(token));
					if(!finalToken.isEmpty()) // if the token is empty, then try next token
					{ 

						synchronized(lock1) {
							//unigram
							if(!m_unigramLM.m_model.containsKey(finalToken))  
								m_unigramLM.m_model.put(finalToken, new Token(finalToken));

							m_unigramLM.m_model.get(finalToken).setValue(m_unigramLM.m_model.get(finalToken).getValue()+1);// increase count
							TotalNumberOfWords++;

							// bigram
							if(!previousToken.isEmpty()){
								String vocabID=previousToken+"-"+finalToken;
								if(!m_bigramLM.m_model.containsKey(vocabID)) 
									m_bigramLM.m_model.put(vocabID, new Token(vocabID));

								m_bigramLM.m_model.get(vocabID).setValue(m_bigramLM.m_model.get(vocabID).getValue()+1);// increase count
							}
						}
					}
					previousToken=finalToken;
				}

				synchronized(lock2) {
					m_reviews.add(review);
				}
			}
		} catch (JSONException e) {
			e.printStackTrace();
		}
	}
	//sample code for loading a json file
	public JSONObject LoadJson(String filename) {
		try {
			BufferedReader reader = new BufferedReader(new InputStreamReader(new FileInputStream(filename), "UTF-8"));
			StringBuffer buffer = new StringBuffer(1024);
			String line;

			while((line=reader.readLine())!=null) {
				buffer.append(line);
			}
			reader.close();

			return new JSONObject(buffer.toString());
		} catch (IOException e) {
			System.err.format("[Error]Failed to open file %s!", filename);
			e.printStackTrace();
			return null;
		} catch (JSONException e) {
			System.err.format("[Error]Failed to parse json file %s!", filename);
			e.printStackTrace();
			return null;
		}
	}
	public void GetTopNWords(String unigram,int N)
	{
		// Calculate Probabilities
		HashMap<Double,String> LIProb=new HashMap<Double,String>();
		HashMap<Double,String> ADProb=new HashMap<Double,String>();
	 
		for(Token t:m_unigramLM.m_model.values())
		{
			LIProb.put(m_bigramLM.calcLinearSmoothedProb(unigram+"-"+t.getToken()), t.getToken());
			ADProb.put(m_bigramLM.calcAbsoluteDiscountSmoothedProb(unigram+"-"+t.getToken()), t.getToken());
		}
		// Sort
		Map<Double,String> LImap = new TreeMap<Double,String>(LIProb).descendingMap(); 
		Map<Double,String> ADmap = new TreeMap<Double,String>(ADProb).descendingMap();
		// Save Top N
		try {
			// LI
			FileWriter fstream = new FileWriter("./IL_"+unigram+".txt", false);
			BufferedWriter out = new BufferedWriter(fstream);

			Set set2 = LImap.entrySet();
			Iterator iterator2 = set2.iterator();
			for(int i=0;i<N&&i<m_unigramLM.m_model.size();++i){
				Map.Entry me2 = (Map.Entry)iterator2.next();
				out.write(me2.getKey()+","+ me2.getValue()+"\n");
			}
			out.close();
			System.out.println("IL_"+unigram+" Saved!");
			// AD
			fstream = new FileWriter("./AD_"+unigram+".txt", false);
			out = new BufferedWriter(fstream);

			set2 = ADmap.entrySet();
			iterator2 = set2.iterator();
			for(int i=0;i<N&&i<m_unigramLM.m_model.size();++i){
				Map.Entry me2 = (Map.Entry)iterator2.next();
				out.write(me2.getKey()+","+ me2.getValue()+"\n");
			}
			out.close();
			System.out.println("AD_"+unigram+" Saved!");
		} catch (Exception e) {
			e.printStackTrace(); 
		}

	}

 
	public ArrayList<String> GetFiles(String folder, String suffix) {
		File dir = new File(folder);
		ArrayList<String> Files=new ArrayList<String>();
		for (File f : dir.listFiles()) {
			if (f.isFile() && f.getName().endsWith(suffix)){
				Files.add(f.getAbsolutePath());
			}
			else if (f.isDirectory())
				Files.addAll(GetFiles(f.getAbsolutePath(), suffix)) ;
		}
		return Files;
	}


	//sample code for demonstrating how to perform text normalization
	public String NormalizationDemo(String token) {
		// convert to lower case
		token = token.toLowerCase();
		//token = token.replaceAll("\\d+star(s)?", "RATE");// rating by stars
		// Some scales and measures
		//token = token.replaceAll("\\d+(oz|lb|lbs|cent|inch|piec)", "SCALE");
		// convert some of the dates/times formats
		//token = token.replaceAll("\\d{2}(:\\d{2})?(\\s)?(a|p)m", "TIME"); // 12 hours format
		//token = token.replaceAll("\\d{2}:\\d{2}", "TIME"); // 24 hours format
		//token = token.replaceAll("\\d{1,2}(th|nd|st|rd)", "DATE");// 1st 2nd 3rd 4th date format
		// convert numbers
		token = token.replaceAll("\\d+.\\d+", "NUM");		
		token = token.replaceAll("\\d+(ish)?", "NUM");
		// tested on "a 123 b 3123 c 235.123 d 0 e 0.3 f 213.231.1321 g +123 h -123.123"
		// remove punctuations
		token = token.replaceAll("\\p{Punct}", ""); 
		//tested on this string:  "This., -/ is #! an <>|~!@#$%^&*()_-+=}{[]\"':;?/>.<, $ % ^ & * example ;: {} of a = -_ string with `~)() punctuation" 
		return token;
	}
	public static void main(String[] args) {	
		int NumberOfProcessors=8;
		DocAnalyzer analyzer = new DocAnalyzer(NumberOfProcessors );

		DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
		  	ArrayList<String>Files=analyzer.GetFiles("./data/Yelp_small/train", ".json");//Yelp_small/train
			int FilesSize=Files.size();
			HashMap<Integer,String> ProcessingStatus = new HashMap<Integer, String>(); // used for output purposes
			for (int i = 1; i <= 10; i++)
			ProcessingStatus.put((int)(FilesSize * (i / 10d)), i+"0% ("+(int)(FilesSize * (i / 10d))+" out of "+FilesSize+")." );
		 	 
		
 
		ArrayList<Thread> threads = new ArrayList<Thread>();
		for(int i=0;i<NumberOfProcessors;++i){
			threads.add(  (new Thread() {
				int core;
				public void run() {
					try {
						for (int j = 0; j + core <FilesSize; j +=NumberOfProcessors)
						{
							if (ProcessingStatus.containsKey(j + core))
								System.out.println(dateFormat.format(new Date())+" - Loaded " +ProcessingStatus.get(j + core));
							analyzer.analyzeDocumentDemo(analyzer.LoadJson(Files.get(j+core)),core);
						}
					} catch (Exception e) {
						e.printStackTrace();
					} 

				}
				private Thread initialize(int core) {
					this.core = core;
					return this;
				}
			}).initialize(i));
			threads.get(i).start();
		}
		for(int i=0;i<NumberOfProcessors;++i){
			try {
				threads.get(i).join();
			} catch (InterruptedException e) {
				e.printStackTrace();
			} 
		}   
	 
		analyzer.m_unigramLM.TotalNumberOfWords=analyzer.TotalNumberOfWords;
		analyzer.GetTopNWords("good",10);
	}



}
